<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ArticaleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
