var DTcustomsetting = {
    languagePagination: {
        "paginate": {
          "previous": "<i class='flaticon-left-arrow-1'></i>",
          "next": "<i class='flaticon-right-arrow-1'></i>"
        },
        "info": "صفحه _PAGE_ از _PAGES_"
    },



};



var DTcustomsetting = {
    languagePagination: {
        "paginate": {
          "previous": "<i class='flaticon-left-arrow-1'></i>",
          "next": "<i class='flaticon-right-arrow-1'></i>"
        },
        "info": "صفحه _PAGE_ از _PAGES_"
    },

    languagePaginate: {
        "previous": "<i class='flaticon-left-arrow-1'></i> Previous",
        "next": "Next <i class='flaticon-right-arrow-1'></i>"
    }

    languageInfo: {
    	"صفحه _PAGE_ از _PAGES_"
    }

    
    
};