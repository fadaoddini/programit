<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 text-center"> © 1398  <span class="text-primary">پروگرمیت</span>
                تمامی حقوق محفوظ است.</div>
        </div>
    </div>
</div>
