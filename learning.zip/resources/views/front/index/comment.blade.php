<div class="section-area section-sp2"
     style="background-image:url({{url('front/assets/images/background/bg7.jpg')}}); background-size:cover;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 heading-bx style1 text-center">
                <h2 class="title-head">سخنان بزرگان</h2>
                <p>
                   ما در اینجا سعی می کنیم به سخنان بزرگان، فیلسوفان و اندیشمندان بپردازیم.

                </p>
            </div>
        </div>
        <div class="testimonial-carousel-2 owl-carousel owl-btn-1 col-12 p-lr0 owl-none">
            <div class="item">
                <div class="testimonial-bx style1">
                    <div class="testimonial-thumb">
                        <img src="{{url('front/assets/images/testimonials/pic1.jpg')}}" alt="">
                    </div>
                    <div class="testimonial-info">
                        <h5 class="name">مولانا</h5>
                        <p>ایرانی</p>
                    </div>
                    <div class="testimonial-content">
                        <p>
                            سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا سخنی از مولانا

                        </p>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="testimonial-bx style1">
                    <div class="testimonial-thumb">
                        <img src="{{url('front/assets/images/testimonials/pic2.jpg')}}" alt="">
                    </div>
                    <div class="testimonial-info">
                        <h5 class="name">سعدی</h5>
                        <p>ایرانی</p>
                    </div>
                    <div class="testimonial-content">
                        <p>
                            سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی سخنی از سعدی
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
