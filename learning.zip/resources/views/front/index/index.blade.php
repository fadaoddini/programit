@include('front.head')

	<div class="page-wraper">
		<div id="loading-icon-bx"></div>
		<!-- Header Top ==== -->
		@include('front.header')
		<!-- Header Top END ==== -->
		<!-- Content -->
		<div class="page-content bg-white">
			<!-- Main Slider -->
			@include('front.revslider')
			<!-- Main Slider -->
			<div class="content-block">
				<!-- Popular Courses -->
				<div class="section-area section-sp2 popular-courses-bx"
					style="background-image:url({{url('front/assets/images/background/bg4.jpg')}}); background-size:cover;">

                    @include('front.index.categories')
                    @include('front.index.mahbob')


				</div>
				<!-- Popular Courses END -->

				<!-- Form -->
				@include('front.index.form')
				<!-- Form END -->
				@include('front.index.roydad')
				<!-- Our Story ==== -->
				@include('front.index.moarefi')
				<!-- Our Story END -->
				<!-- Testimonials -->
				@include('front.index.comment')
				<!-- Testimonials END -->
			</div>
			<!-- contact area END -->
		</div>
		<!-- Content END-->
		<!-- Footer ==== -->
		<footer class="footer-white">
			<div class="footer-top bt0">
				<div class="container">
					@include('front.khabarname')
					@include('front.menufooter')
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 text-center"> © 1398  <span class="text-primary">اجوکمپ</span>
							تمامی حقوق محفوظ است.</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- Footer END ==== -->
		<button class="back-to-top fa fa-chevron-up"></button>
	</div>
@include('front.footer')
