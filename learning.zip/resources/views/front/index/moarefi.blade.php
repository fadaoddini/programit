<div class="section-area bg-gradient section-sp1 our-story popp">
    <div class="container">
        <div class="row align-items-center d-flex">
            <div class="col-lg-5 col-md-12 heading-bx text-white style1 ">
                <h2 class="title-head">داستان ما</h2>
                <h5 class="fw4"> دوست دارید در مورد ویکی بیشتر بدانید</h5>
                <p>
                    می توانید فیلم کوتاهی که ما برای شما تدارک دیده ایم را ببینید و یا به صفحه درباره ما مراجعه کنید
                </p>
                <a href="#" class="btn">درباره ما</a>
            </div>
            <div class="col-lg-7 col-md-12 heading-bx p-lr">
                <div class="video-bx">
                    <img src="{{url('front/assets/images/about/pic1.jpg')}}" alt="" />
                    <a href="https://www.youtube.com/watch?v=x_sJzVe9P_8" class="popup-youtube video"><i
                            class="fa fa-play"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
