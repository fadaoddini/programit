<div class="subscribe-box">
    <div class="subscribe-title">
        <h4>عضو شوید تا از آخرین خبرها مطلع شوید</h4>
    </div>
    <div class="subscribe-form m-b20">
        <form class="subscription-form" action=" "
              method="post">
            <div class="ajax-message"></div>
            <div class="input-group">
                <input name="email" required="required" class="form-control" placeholder="پست الکترونیک شما"
                       type="email">
                <span class="input-group-btn">
										<button name="submit" value="Submit" type="submit" class="btn radius-xl">اشتراک</button>
									</span>
            </div>
        </form>
    </div>
</div>
