@include('front.head')


<div class="page-wraper">

    @yield('content')


</div>
<!-- External JavaScripts -->
@include('front.footer')
