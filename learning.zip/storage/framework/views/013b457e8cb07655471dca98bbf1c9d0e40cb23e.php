<?php echo $__env->make('front.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-wraper">
    <div id="loading-icon-bx"></div>
    <!-- Header Top ==== -->
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header Top END ==== -->
    <!-- Content -->
    <div class="page-content bg-white">


        <!-- inner page banner -->
        <div class="page-banner ovbl-dark" style="background-image:url(<?php echo e(url('front/assets/images/banner/banner3.jpg')); ?>);">
            <div class="container">
                <div class="page-banner-entry">
                    <h1 class="text-white"><?php echo e($title_course); ?></h1>
                </div>
            </div>
        </div>
        <!-- Breadcrumb row -->
        <div class="breadcrumb-row">
            <div class="container">
                <ul class="list-inline">
                    <li><a href="<?php echo e(route('index')); ?>">خانه</a></li>
                    <li ><a href="<?php echo e(route('index.courses',$cat->id)); ?>"><?php echo e($cat->name); ?></a></li>
                    <li ><?php echo e($title_course); ?></li>
                </ul>
            </div>
        </div>
        <div class="content-block">
            <!-- About Us -->
            <div class="section-area section-sp1">
                <div class="container">
                    <div class="row d-flex flex-row-reverse">
                        <div class="col-lg-3 col-md-4 col-sm-12 m-b30">
                            <div class="course-detail-bx">
                                <div class="course-price">
                                    <del>

                                        <?php echo e($course->price); ?>



                                        تومان </del>
                                    <h4 class="price">

                                        <?php echo e($course->price-(($course->price*$course->takhfif)/100)); ?>


                                        تومان </h4>
                                </div>
                                <div class="course-buy-now text-center">
                                    <a href="#" class="btn radius-xl text-uppercase">خرید دوره</a>
                                </div>
                                <div class="teacher-bx">
                                    <div class="teacher-info">
                                        <div class="teacher-thumb">
                                            <img src="<?php echo e($cat->images['thumb']); ?>" alt="" />
                                        </div>
                                        <div class="teacher-name">
                                            <h5>
                                                <a href="<?php echo e(route('index.courses',$cat->id)); ?>" >
                                                <?php echo e($cat->name); ?>

                                                </a>
                                            </h5>
                                  
                                        </div>
                                    </div>
                                </div>

                                <div class="course-info-list scroll-page">
                                    <ul class="navbar">


                                        <li class="px-4 py-1"><a class="nav-link" href=" <?php echo e($epizod_one->videoUrl); ?>"><i class="ti-zip"></i>دانلود این قسمت</a></li>
                                       



                                        

                                     


                                        <?php if(! $epizod_one->images=='no files'): ?>
                                        <li class="px-4 py-1"><a class="nav-link" href=" <?php echo e($epizod_one->images); ?>"><i class="ti-zip"></i>دانلود تکمیلی</a></li>

                                        <?php endif; ?>

                                        <li class="px-4 py-1"><a class="nav-link" ><i class="ti-time"></i>زمان آموزش

                                            |  <?php echo e($epizod_one->time); ?>


                                            </a></li>


                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-9 col-md-8 col-sm-12">

                            <div class="courses-post">
                                <div class="ttr-post-media media-effect">


                                    <video id="video" poster="<?php echo e($course->images['thumb']); ?>" controls="" width="100%" >
                                        <source src="<?php echo e($epizod_one->videoUrl); ?>" type="video/mp4">
                                        <source src="<?php echo e($epizod_one->videoUrl); ?>" type="video/avi">
                                    </video>


                                </div>




                                <div class="ttr-post-info">
                                    <div class="ttr-post-title ">
                                        <h2 class="post-title"><?php echo e($course->name); ?></h2>
                                    </div>
                                    <div class="ttr-post-text pt-5 pb-3">
                                        <p class="pr-4">

                                            <?php echo e($course->lid); ?>


                                        </p>
                                        <hr>
                                        <p class="pr-4">

                                            <?php echo e($course->description); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="m-b30" id="curriculum">
                                <h4>محتوا و لینک ها</h4>



                                <div class="col-md-12">
                                    <div class="why-chooses-bx ">
                                        <div class="ttr-accordion m-b30 faq-bx" id="accordion1">


                                            <?php $__currentLoopData = $epizods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="panel">
                                                <div class="acod-head">
                                                    <h6 class="acod-title">
                                                        <a data-toggle="collapse" href="#faq1" class="" data-parent="#faq<?php echo e($row->number); ?>" aria-expanded="true">

                                                        <?php echo e($row->name); ?>


                                                        </a> </h6>
                                                </div>
                                                <div id="faq<?php echo e($row->number); ?>" class="acod-body collapse show" style="">
                                                    <div class="acod-content">
                                                        <?php echo e($row->description); ?>


                                                        <hr>

                                                        <div class="course-buy-now text-center">
                                                            <a href="<?php echo e(route('index.onedetails', [$row->course_id,$row->id])); ?>" class="btn radius-xl text-uppercase">نمایش محتوا</a>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </div>
                                    </div>
                                    <div></div></div>


                            </div>


                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- contact area END -->
    </div>
    <!-- Content END-->

    <button class="back-to-top fa fa-chevron-up"></button>
</div>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\xamp\htdocs\learning\resources\views/front/coursedetail/indexone.blade.php ENDPATH**/ ?>