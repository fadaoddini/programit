<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>الگوی مدیریت CORK - داشبورد تحلیلی</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(url('admin/assets/img/favicon.ico')); ?>"/>

    <link href="<?php echo e(url('admin/assets/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(url('admin/assets/js/loader.js')); ?>"></script>

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
   


    <link href="<?php echo e(url('admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/structure.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/structure.css')); ?>" rel="stylesheet" type="text/css" class="structure">
    <link href="<?php echo e(url('admin/assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/assets/css/elements/infobox.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/plugins/table/datatable/datatables.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/plugins/table/datatable/dt-global_style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/plugins/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/assets/css/elements/alert.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('admin/assets/css/forms/theme-checkbox-radio.css')); ?>" rel="stylesheet" type="text/css">




    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />


</head>
<style>
    /*
        The below code is for DEMO purpose --- Use it if you are using this demo otherwise Remove it
    */

    .navbar .navbar-item.navbar-dropdown {
        margin-right: auto;
    }

    /*
        ====================
            IE Support
        ====================
    */

    @media  all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
        .header-container { width: 100%; }
    }

    /*
        Just for demo purpose ---- Remove it.
    */
    /*<starter kit design>*/

    .widget-one {

    }
    .widget-one h6 {
        font-size: 20px;
        font-weight: 600;
        letter-spacing: 0px;
        margin-bottom: 22px;
    }
    .widget-one p {
        font-size: 15px;
        margin-bottom: 0;
    }

</style>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/admin/core/head.blade.php ENDPATH**/ ?>