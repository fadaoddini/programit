<header class="header rs-nav header-transparent">
    <div class="top-bar">
        <div class="container">
            <div class="row d-flex justify-content-between">
                <div class="topbar-left">
                    <ul>
                       
                       
                    </ul>
                </div>
                <div class="topbar-right">
                    <ul>
                        <?php if(auth()->guard()->check()): ?>
                            <li ><a href="#">سلام،

                                    <?php echo e(Auth::user()->family); ?>

                                </a>


                                    <?php if(Auth::user()->role=='1'): ?>

                                        <li><a style="padding: 5px 15px;" href="<?php echo e(route('admin.index')); ?>" target="_blank" class="btn btn-danger">
                                                مدیریت </a></li>
                                    <?php endif; ?>
                                    
                                    <li>
                                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button style="padding: 5px 15px;" type="submit" class="btn btn-danger btn-sm">خروج</button>

                                        </form>
                                    </li>

                            </li>


                        <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">ورود</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">ثبت نام</a></li>


                        <?php endif; ?>
                            <li class="search-btn"><button id="quik-search-btn" type="button" class="btn-link"><i
                                        class="fa fa-search"></i></button></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <div class="sticky-header navbar-expand-lg">
        <div class="menu-bar clearfix">
            <div class="container clearfix">
                <!-- Header Logo ==== -->
                <div class="menu-logo logo-change">
                    <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(url('front/assets/images/logo-3.png')); ?>" class="logo1" alt=""><img
                            src="<?php echo e(url('front/assets/images/logo-white-3.png')); ?>" class="logo2" alt=""></a>
                </div>
                <!-- Mobile Nav Button ==== -->
                <button class="navbar-toggler collapsed menuicon justify-content-start" type="button" data-toggle="collapse"
                        data-target="#menuDropdown" aria-controls="menuDropdown" aria-expanded="false"
                        aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <!-- Author Nav ==== -->
                <div class="secondary-menu">
                    <div class="secondary-inner">
                        <ul>
                            
                            <!-- Search Button ==== -->

                        </ul>
                    </div>
                </div>
                <!-- Search Box ==== -->
                <div class="nav-search-bar">
                    <form action="#">
                        <input name="search" value="" type="text" class="form-control" placeholder="جستجو...">
                        <span><i class="ti-search"></i></span>
                    </form>
                    <span id="search-remove"><i class="ti-close"></i></span>
                </div>
                <!-- Navigation Menu ==== -->
                <div class="menu-links navbar-collapse collapse justify-content-start" id="menuDropdown">
                    <div class="menu-logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(url('front/assets/images/logo.png')); ?>" alt=""></a>
                    </div>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo e(route('index')); ?>">خانه </a>

                        </li>

                        <?php $__currentLoopData = $categoryasli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="add-mega-menu"><a href="javascript:;"><?php echo e($cat->name); ?> <i class="fa fa-chevron-down"></i></a>
                                <ul class="sub-menu add-menu">
                                    <li class="add-menu-left">
                                        <h5 class="menu-adv-title">

                                        <a href="<?php echo e(route('index.courses',$cat->id)); ?>">
                                            <?php echo e($cat->name); ?>

                                        </a>
                                        </h5>
                                        <ul>
                                            <li><a href="<?php echo e(route('index.courses',$cat->id)); ?>"><?php echo e($cat->lid); ?></a></li>


                                        </ul>
                                    </li>
                                    <li class="add-menu-right">
                                        <img class="rounded-circle" src="<?php echo e($cat->images['thumb']); ?>" alt="" />
                                    </li>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                    <div class="nav-social-link">
                       
                    </div>
                </div>
                <!-- Navigation Menu END ==== -->
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/front/header.blade.php ENDPATH**/ ?>