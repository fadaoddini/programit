<?php $__env->startSection('content'); ?>
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="page-header">
                <div class="page-title">
                    <h3>زیر مجموعه برای

                        <span class=" float-right mr-4  " style="font-size: 24px; display: contents; color: #ff376e; ">
                        <?php echo e($category->name); ?>

                    </span>

                    </h3>




                </div>
            </div>
            <?php echo $__env->make('admin.core.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row layout-top-spacing">
                

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style="margin-bottom:24px;">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    <h4>در حال ایجاد کردن زیر دسته برای <?php echo e($category->name); ?> هستید</h4>
                                </div>
                            </div>
                        </div>
                        <div class="widget-content widget-content-area" >
                            <form action="<?php echo e(route('create.categoryto')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="name">عنوان</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name"
                                                   placeholder="عنوان" value="<?php echo e(old('name')); ?>">
                                            <small>نام دسته بندی</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="name">زیرمجموعه</label>
                                            <select name="idcat1" class="form-control selectpicker" data-live-search="false">
                                                <option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>

                                            </select>
                                            <small>قابل تغییر نیست</small>


                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="lid">لید</label>
                                            <textarea type="text" rows="2" name="lid" class="form-control"
                                                      id="lid"><?php echo e(old('lid')); ?></textarea>
                                            <small>توضیحی کوتاه و کامل از دسته بندی را اینجا بنویسید</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="description">توضیحات</label>
                                            <textarea type="text" rows="6" name="description" class="form-control"
                                                      id="description"><?php echo e(old('description')); ?></textarea>
                                            <small>توضیح کامل از دسته بندی را اینجا بنویسید</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="tags">تگ</label>
                                            <input type="text" class="form-control" name="tags" id="tags"
                                                   value="<?php echo e(old('tags')); ?>">
                                            <small>تگ ها برای موتورهای جستجو و سئو مناسب هستند لطفا کلمات با کامای انگلیسی جدا شوند</small>
                                        </div>


                                        <div class="form-group col-md-12">

                                        </div>
                                        <div class="form-group col-md-12">

                                        </div>

                                    </div>
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="status">وضعیت</label>
                                            <select id="status" name="status" class="form-control">
                                                <option value="1" >فعال</option>
                                                <option value="0">غیرفعال</option>
                                            </select>
                                            <small>می توانید با غیر فعال کردن دسته آن را از دید کاربران پنهان کنید</small>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="images">تصویر اصلی</label>
                                            <input type="file" class="form-control " name="images" id="images"
                                                   >
                                            <small>برای معرفی بهتر دسته ایجاد شده کاربرد دارد</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="video">فیلم</label>
                                            <input type="file" class="form-control " name="video" id="video"
                                            >
                                            <small>برای معرفی ویدئویی دسته ایجاد شده کاربرد دارد</small>
                                        </div>

                                    </div>
                                </div>






                                <button type="submit" class="col-12 btn btn-primary mt-3">ایجاد</button>
                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="footer-wrapper">
            <div class="footer-section f-section-1">
                <p class=""> © کپی رایت</p>
            </div>
            <div class="footer-section f-section-2">
                <span class="copyright"> بومی سازی شده توسط : <a href=""> محمد سعید فداالدینی </a> </span></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\learning\resources\views/admin/category/createcategorysub.blade.php ENDPATH**/ ?>