<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 heading-bx style1 text-center">
            <h2 class="title-head">پیشنهادات ویژه</h2>
            <p>

                ما برای شما پیشنهاداتی داریم که می توانید از آن ها لذت ببرید

            </p>
        </div>
    </div>
    <div class="row">
        <div class="courses-carousel-2 owl-carousel owl-btn-1 col-12 p-lr0 owl-none">

<?php $__currentLoopData = $coursevije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vije): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="item">
                <div class="cours-bx style1">
                    <div class="action-box">
                        <img  src="<?php echo e($vije->images['thumb']); ?>" alt="">
                        <a href="<?php echo e(route('index.details',$vije->slug)); ?>" class="btn">جزئیات</a>
                    </div>
                    <div class="info-bx text-center">
                        <h5 style="font-size: 12px;"><a href="#"><?php echo e($vije->name); ?></a></h5>
                        <span><?php echo e($vije->role); ?></span>
                    </div>
                    <div class="cours-more-info">
                        <div class="review">
                            <span>3 نظرات</span>
                            <ul class="cours-star">
                                <li class="active"><i class="fa fa-star"></i></li>
                                <li class="active"><i class="fa fa-star"></i></li>
                                <li class="active"><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                            </ul>
                        </div>
                        <div class="price">
                            <del>

                                <?php echo e($vije->price); ?>


                                تومان </del>
                            <h5>

                                <?php echo e(($vije->price*$vije->takhfif)/100); ?>

                                تومان </h5>
                        </div>
                    </div>
                </div>
            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/front/index/mahbob.blade.php ENDPATH**/ ?>