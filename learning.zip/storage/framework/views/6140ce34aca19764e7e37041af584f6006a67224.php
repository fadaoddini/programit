<?php echo $__env->make('front.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="page-wraper">
		<div id="loading-icon-bx"></div>
		<!-- Header Top ==== -->
		<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- Header Top END ==== -->
		<!-- Content -->
		<div class="page-content bg-white">
			<!-- Main Slider -->
			<?php echo $__env->make('front.revslider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- Main Slider -->
			<div class="content-block">
				<!-- Popular Courses -->
				<div class="section-area section-sp2 popular-courses-bx"
					style="background-image:url(<?php echo e(url('front/assets/images/background/bg4.jpg')); ?>); background-size:cover;">

                    <?php echo $__env->make('front.index.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('front.index.mahbob', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				</div>
				<!-- Popular Courses END -->

				<!-- Form -->
				<?php echo $__env->make('front.index.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- Form END -->
				<?php echo $__env->make('front.index.roydad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- Our Story ==== -->
				<?php echo $__env->make('front.index.moarefi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- Our Story END -->
				<!-- Testimonials -->
				<?php echo $__env->make('front.index.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- Testimonials END -->
			</div>
			<!-- contact area END -->
		</div>
		<!-- Content END-->
		<!-- Footer ==== -->
		<footer class="footer-white">
			<div class="footer-top bt0">
				<div class="container">
					<?php echo $__env->make('front.khabarname', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php echo $__env->make('front.menufooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 text-center"> © 1398  <span class="text-primary">اجوکمپ</span>
							تمامی حقوق محفوظ است.</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- Footer END ==== -->
		<button class="back-to-top fa fa-chevron-up"></button>
	</div>
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/front/index/index.blade.php ENDPATH**/ ?>