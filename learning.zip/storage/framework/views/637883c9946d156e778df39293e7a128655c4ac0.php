<?php $__env->startSection('content'); ?>

    <style>
        .zirdaste{
            display: none;
        }
        .nist{
            display: none;
        }

        .hast{
            display: block;
        }
    </style>
    <div id="content" class="main-content">
        <div class="layout-px-spacing">


            <div class="page-header">
                <div class="page-title">
                    <h3>ویرایش دوره</h3>
                </div>
            </div>
            <?php echo $__env->make('admin.core.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="row layout-top-spacing">
                

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style="margin-bottom:24px;">
                    <div class="statbox widget box box-shadow">

                        <div class="widget-content widget-content-area" >

                            <form action="<?php echo e(route('course.update',$course->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="name">عنوان</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name"
                                                    value="<?php echo e($course->name); ?>">
                                            <small>عنوان دوره</small>
                                        </div>

                                        <?php if(isset($cat_id1)): ?>

                                            <div  class="form-group col-md-12">
                                                <label for="name">دسته مادر</label>
                                                <select onchange="checkedidcat(this)" name="cat_id1" class="form-control selectpicker" data-live-search="true">

                                                    <?php $__currentLoopData = $cat_id1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option data-cat="<?php echo e($cat_id); ?>" value="<?php echo e($cat_id); ?>"
                                                        <?php
                                                            if (in_array($cat_id, $course->pluck('id')->toArray())) echo "selected"
                                                            ?>

                                                        >
                                                            <?php echo e($cat_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php $__currentLoopData = $idcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-cat="<?php echo e($cat_id); ?>" value="<?php echo e($cat_id); ?>">
                                                                <?php echo e($cat_name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>




                                            </div>


                                            <?php else: ?>

                                            <div  class="form-group col-md-12">
                                                <label for="name">دسته مادر</label>
                                                <select onchange="checkedidcat(this)" name="cat_id1" class="form-control selectpicker" data-live-search="true">

                                                    <option value="0" selected> انتخاب کنید (پیش فرض والد)</option>
                                                    <?php $__currentLoopData = $idcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option data-cat="<?php echo e($cat_id); ?>" value="<?php echo e($cat_id); ?>"
                                                        <?php
                                                            if (in_array($cat_id, $course->pluck('id')->toArray())) echo "selected"
                                                            ?>

                                                        >
                                                            <?php echo e($cat_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>




                                            </div>

                                            <?php endif; ?>






                                        <?php if(isset($cat_id2)): ?>



                                            <div  class="form-group col-md-12 avali ">
                                                <label for="name">زیردسته</label>
                                                <select onchange="checkedidcat2(this)" id="zirdaste2"  name="cat_id2" autocomplete="off"  class="form-control selectpicker  ">

                                                    <?php $__currentLoopData = $cat_id2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option data-cat="<?php echo e($cat_id); ?>" value="<?php echo e($cat_id); ?>"
                                                        <?php
                                                            if (in_array($cat_id, $course->pluck('id')->toArray())) echo "selected"
                                                            ?>

                                                        >
                                                            <?php echo e($cat_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>



                                            </div>

                                            <?php else: ?>
                                            <div  class="form-group col-md-12 avali nist">
                                                <label for="name">زیردسته</label>
                                                <select onchange="checkedidcat2(this)" id="zirdaste2"  name="cat_id2" autocomplete="off"  class="form-control selectpicker  ">

                                                </select>



                                            </div>

                                            <?php endif; ?>








                                        <?php if(isset($cat_id3)): ?>
                                            <div  class="form-group col-md-12 sevom ">
                                                <label for="name">سطح سوم</label>
                                                <select  id="zirdaste3"  name="cat_id3" autocomplete="off"  class="form-control selectpicker  ">
                                                    <?php $__currentLoopData = $cat_id3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option data-cat="<?php echo e($cat_id); ?>" value="<?php echo e($cat_id); ?>"
                                                        <?php
                                                            if (in_array($cat_id, $course->pluck('id')->toArray())) echo "selected"
                                                            ?>

                                                        >
                                                            <?php echo e($cat_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>



                                            </div>



                                        <?php else: ?>
                                        <div  class="form-group col-md-12 sevom nist">
                                            <label for="name">سطح سوم</label>
                                            <select  id="zirdaste3"  name="cat_id3" autocomplete="off"  class="form-control selectpicker  ">

                                            </select>



                                        </div>

                                        <?php endif; ?>








                                        <div class="form-group ">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label for="price">قیمت</label>
                                                        <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" id="price"
                                                               value="<?php echo e($course->price); ?>">
                                                        <small>قیمت دوره به تومان اگر عددی قرار نگیرد بصورت پیش فرض 0 می باشد</small>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="takhfif">تخفیف</label>
                                                        <input type="number" class="form-control <?php $__errorArgs = ['takhfif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="takhfif" id="takhfif"
                                                               value="<?php echo e($course->takhfif); ?>">
                                                        <small>تخفیف دوره به درصد اگر عددی قرار نگیرد بصورت پیش فرض 0 می باشد</small>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="lid">لید</label>
                                            <textarea type="text" rows="2" name="lid" class="form-control"
                                                      id="lid"><?php echo e($course->lid); ?></textarea>
                                            <small>توضیحی کوتاه و کامل از دوره را اینجا بنویسید</small>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="description">توضیحات</label>
                                            <textarea type="text" rows="6" name="description" class="form-control"
                                                      id="description"><?php echo e($course->description); ?></textarea>
                                            <small>توضیح کامل از دوره را اینجا بنویسید</small>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="tags">تگ</label>
                                            <input type="text" class="form-control" name="tags" id="tags"
                                                   value="<?php echo e($course->tags); ?>">
                                            <small>تگ ها برای موتورهای جستجو و سئو مناسب هستند لطفا کلمات با کامای انگلیسی جدا شوند</small>
                                        </div>




                                    </div>
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="status">وضعیت</label>
                                            <select id="status" name="status" class="form-control">
                                                <option value="1" <?php echo e($course->status=="1" ? 'selected' : ''); ?> >فعال</option>
                                                <option value="0" <?php echo e($course->status=="0" ? 'selected' : ''); ?>>غیرفعال</option>
                                            </select>
                                            <small>می توانید با غیر فعال کردن دوره آن را از دید کاربران پنهان کنید</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="role">ویژه/رایگان/نقدی</label>
                                            <select id="role" name="role" class="form-control">
                                                <option value="vip" <?php echo e($course->role=="vip" ? 'selected' : ''); ?> >VIP</option>
                                                <option value="free" <?php echo e($course->role=="free" ? 'selected' : ''); ?>>رایگان</option>
                                                <option value="cash" <?php echo e($course->role=="cash" ? 'selected' : ''); ?>>نقدی</option>
                                            </select>
                                            <small>دوره شما چه وضعیتی دارد بصورت پیش فرض روی نقدی می باشد</small>
                                        </div>


                                        <div class="col-md-12">
                                            <div class="row">

                                                <?php $__currentLoopData = $course->images['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                    <div class="col-md-3">
                                                        <label class="new-control new-radio new-radio-text radio-classic-success">
                                                            <input class="new-control-input" name="imagestumb" type="radio" value="<?php echo e($img); ?>" <?php echo e($course->images['thumb']==$img ? 'checked' : ''); ?>>
                                                            <span class="new-control-indicator"></span><span class="new-radio-content">      <?php echo e($key); ?></span>
                                                        </label>

                                                        <a href="<?php echo e($img); ?>">
                                                            <img width="100%" src="<?php echo e($img); ?>">
                                                        </a>



                                                    </div>


                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>
                                        </div>




                                    
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <input type="text" id="image_label" class="form-control" name="video"
                                                       aria-label="Image" aria-describedby="button-image" value="<?php echo e($course->video); ?>">
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-secondary" type="button" id="button-image">انتخاب</button>
                                                </div>
                                            </div>

                                            <small>فرمت قابل قبول mp4 می باشد</small>
                                        </div>




                                    </div>
                                </div>






                                <button type="submit" class="col-12 btn btn-primary mt-3">ویرایش</button>
                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="footer-wrapper">
            <div class="footer-section f-section-1">
                <p class=""> © کپی رایت</p>
            </div>
            <div class="footer-section f-section-2">
                <span class="copyright"> بومی سازی شده توسط : <a href=""> محمد سعید فداالدینی </a> </span></div>
        </div>
    </div>


    <script>
        document.addEventListener("DOMContentLoaded", function() {

            document.getElementById('button-image').addEventListener('click', (event) => {
                event.preventDefault();

                window.open('/file-manager/fm-button', 'fm', 'width=1400,height=800');
            });
        });

        // set file link
        function fmSetLink($url) {
            document.getElementById('image_label').value = $url;
        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\learning\resources\views/admin/course/editcourse.blade.php ENDPATH**/ ?>