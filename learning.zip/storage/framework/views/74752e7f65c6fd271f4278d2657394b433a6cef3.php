<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('admin.core.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="dashboard-analytics">

<!-- BEGIN LOADER -->
<div id="load_screen"> <div class="loader"> <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div></div></div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php echo $__env->make('admin.core.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php echo $__env->make('admin.core.sidebare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  END SIDEBAR  -->




    <!--  BEGIN CONTENT AREA  -->


    <?php echo $__env->yieldContent('content'); ?>



    <!--  END CONTENT AREA  -->


</div>
<!-- END MAIN CONTAINER -->





<?php echo $__env->make('admin.core.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/admin/master.blade.php ENDPATH**/ ?>