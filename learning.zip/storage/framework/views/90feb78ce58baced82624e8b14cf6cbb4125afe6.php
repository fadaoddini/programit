<?php echo $__env->make('front.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="page-wraper">

    <?php echo $__env->yieldContent('content'); ?>


</div>
<!-- External JavaScripts -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xamp\htdocs\learning\resources\views/front/main.blade.php ENDPATH**/ ?>