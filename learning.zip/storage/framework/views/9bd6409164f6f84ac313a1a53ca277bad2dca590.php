
<script src="<?php echo e(url('admin/assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/assets/js/app.js')); ?>"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo e(url('admin/assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(url('admin/plugins/apex/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/assets/js/dashboard/dash_1.js')); ?>"></script>



<?php /**PATH D:\laravel\learning\resources\views/admin/core/foot.blade.php ENDPATH**/ ?>