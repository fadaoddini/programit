<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>الگوی مدیریت CORK - داشبورد تحلیلی</title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <link href="assets/css/loader.css" rel="stylesheet" type="text/css" />
    <script src="assets/js/loader.js"></script>

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">


    <link href="<?php echo e(url('admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/structure.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('admin/assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />

</head>
<?php /**PATH D:\laravel\learning\resources\views/admin/core/head.blade.php ENDPATH**/ ?>