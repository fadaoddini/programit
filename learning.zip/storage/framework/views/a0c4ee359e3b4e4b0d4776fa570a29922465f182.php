<?php $__env->startSection('content'); ?>

    <style>
        .zirdaste{
            display: none;
        }
        .nist{
            display: none;
        }

        .hast{
            display: block;
        }
    </style>
    <div id="content" class="main-content">
        <div class="layout-px-spacing">


            <div class="page-header">
                <div class="page-title">
                    <h3> ویرایش رسانه</h3>
                </div>
            </div>
            <?php echo $__env->make('admin.core.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="row layout-top-spacing">
                

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style="margin-bottom:24px;">
                    <div class="statbox widget box box-shadow">

                        <div class="widget-content widget-content-area" >

                            <form action="<?php echo e(route('epizod.update',$epizod->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="name">عنوان</label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name"
                                                   value="<?php echo e($epizod->name); ?>">
                                            <small>عنوان رسانه</small>
                                        </div>



                                        <div  class="form-group col-md-12">
                                            <label for="course_id">مربوط به دوره</label>
                                            <select  name="course_id" class="form-control selectpicker" data-live-search="true">

                                                <option  selected> انتخاب کنید </option>
                                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_name => $cat_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cat_id); ?>"
                                                    <?php
                                                        if (in_array($cat_id, $epizod->pluck('id')->toArray())) echo "selected"
                                                        ?>

                                                    >
                                                        <?php echo e($cat_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>




                                        </div>

                               
                                        <div class="form-group col-md-12">
                                            <div class="input-group">
                                                <input type="text" id="image_label" class="form-control" name="videoUrl"
                                                       aria-label="Image" aria-describedby="button-image" value="<?php echo e($epizod->videoUrl); ?>">
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-secondary" type="button" id="button-image">انتخاب</button>
                                                </div>
                                            </div>

                                            <small>فرمت قابل قبول mp4 می باشد</small>
                                        </div>



                                        <div class="form-group ">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label for="time">زمان فیلم</label>
                                                        <input type="text" class="form-control <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="time" id="time"
                                                               value="<?php echo e($epizod->time); ?>">
                                                        <small>قفرمت بصورت (00:00:00) وارد شود</small>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="number">قسمت</label>
                                                        <input type="text" class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="number" id="number"
                                                               value="<?php echo e($epizod->number); ?>">
                                                        <small>جلسه چندم محتوای تولید شده است</small>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>










                                        <div class="form-group col-md-12">
                                            <label for="lid">لید</label>
                                            <textarea type="text" rows="2" name="lid" class="form-control"
                                                      id="lid"><?php echo e($epizod->lid); ?></textarea>
                                            <small>توضیحی کوتاه و کامل از رسانه را اینجا بنویسید</small>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="description">توضیحات</label>
                                            <textarea type="text" rows="6" name="description" class="form-control"
                                                      id="description"><?php echo e($epizod->description); ?></textarea>
                                            <small>توضیح کامل از رسانه را اینجا بنویسید</small>
                                        </div>


                                        <div class="form-group col-md-12">
                                            <label for="tags">تگ</label>
                                            <input type="text" class="form-control" name="tags" id="tags"
                                                   value="<?php echo e($epizod->tags); ?>">
                                            <small>تگ ها برای موتورهای جستجو و سئو مناسب هستند لطفا کلمات با کامای انگلیسی جدا شوند</small>
                                        </div>




                                    </div>
                                    <div class=" col-md-6 mb-4">
                                        <div class="form-group col-md-12">
                                            <label for="status">وضعیت</label>
                                            <select id="status" name="status" class="form-control">
                                                <option value="1" <?php echo e($epizod->status=="1" ? 'selected' : ''); ?> >فعال</option>
                                                <option value="0" <?php echo e($epizod->status=="0" ? 'selected' : ''); ?>>غیرفعال</option>
                                            </select>
                                            <small>می توانید با غیر فعال کردن رسانه آن را از دید کاربران پنهان کنید</small>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="type">ویژه/رایگان/نقدی</label>
                                            <select id="type" name="role" class="form-control">
                                                <option value="vip" <?php echo e($epizod->type=="vip" ? 'selected' : ''); ?> >VIP</option>
                                                <option value="free" <?php echo e($epizod->type=="free" ? 'selected' : ''); ?>>رایگان</option>
                                                <option value="cash" <?php echo e($epizod->type=="cash" ? 'selected' : ''); ?>>نقدی</option>
                                            </select>
                                            <small>رسانه شما چه وضعیتی دارد بصورت پیش فرض روی نقدی می باشد</small>
                                        </div>



                                        <div class="form-group col-md-12">
                                            <label for="images">محتوای رسانه</label>
                                            <input type="file" class="form-control " name="images" id="images" value="<?php echo e($epizod->images); ?>"
                                            >
                                            <small>این محتوا در قالب فایل قابل دانلود به کاربر نمایش داده می شود</small>
                                            <br>
                                            <small>


                                            <a href="<?php echo e($epizod->images); ?>" class="btn btn-success btn-xs">
                                                لینک دانلود
                                            </a>
                                            </small>
                                        </div>




                                    </div>
                                </div>






                                <button type="submit" class="col-12 btn btn-primary mt-3">ویرایش</button>
                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="footer-wrapper">
            <div class="footer-section f-section-1">
                <p class=""> © کپی رایت</p>
            </div>
            <div class="footer-section f-section-2">
                <span class="copyright"> بومی سازی شده توسط : <a href=""> محمد سعید فداالدینی </a> </span></div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

            document.getElementById('button-image').addEventListener('click', (event) => {
                event.preventDefault();

                window.open('/file-manager/fm-button', 'fm', 'width=1400,height=800');
            });
        });

        // set file link
        function fmSetLink($url) {
            document.getElementById('image_label').value = $url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\learning\resources\views/admin/epizod/editepizod.blade.php ENDPATH**/ ?>